# 验收记录

## 测试环境

- 操作系统：Windows
- 浏览器：Microsoft Edge 156（Headless）
- 页面协议：`file://`（不启动构建工具，不连接外部资源）
- 测试方式：Chrome DevTools Protocol 设置视口，读取 `document.documentElement.scrollWidth / clientWidth`、`getComputedStyle()` 与真实 DOM 交互，同时输出全页截图。

> Windows 无头浏览器会保留约 15px 的垂直滚动条宽度，因此视口为 320px 时页面布局宽度为 305px；下表以“`scrollWidth` 不超过 `clientWidth`”判定无横向滚动。

## 1. 视口与三档断点

| 视口宽度 | 卡片列数 | 侧栏形态 | 横向滚动 |
| ---: | ---: | --- | --- |
| 320px | 1 | 抽屉（隐藏） | 无 |
| 360px | 1 | 抽屉（隐藏） | 无 |
| 375px | 1 | 抽屉（隐藏） | 无 |
| 390px | 1 | 抽屉（隐藏） | 无 |
| 480px | 1 | 抽屉（隐藏） | 无 |
| 767px | 1 | 抽屉（隐藏） | 无 |
| 768px | 2 | 抽屉（隐藏） | 无 |
| 900px | 2 | 抽屉（隐藏） | 无 |
| 1024px | 2 | 抽屉（隐藏） | 无 |
| 1199px | 2 | 抽屉（隐藏） | 无 |
| 1200px | 4 | 常驻侧栏 | 无 |
| 1366px | 4 | 常驻侧栏 | 无 |
| 1440px | 4 | 常驻侧栏 | 无 |
| 1600px | 4 | 常驻侧栏 | 无 |
| 1920px | 4 | 常驻侧栏 | 无 |

- 767px：`grid-template-columns` 为 1 列。
- 768px：切换为 2 列。
- 1200px：切换为 4 列，同时侧栏 `position: sticky` 可见，菜单按钮隐藏。
- 1200px 下卡片宽度约 208px，四列完整容纳，无文字或数字撑破卡片。
- 1440px 下最后两张卡片各跨 2 列，第二行铺满。

## 2. 数据与 HTML 结构

| 检查项 | 结果 |
| --- | --- |
| 页面卡片数量 | 6 |
| 卡片标签 | 全部为 `<section class="stat-card">` |
| HTML 中预置卡片 | 0（`#cardGrid` 为空，由 JS 渲染） |
| `h1` 数量 | 1 |
| `h2` 数量 | 3（核心指标、一周营收走势、订单从哪里来） |
| 卡片标题 | 每张一个 `h3`，以 `aria-labelledby` 关联 |
| 卡片图标 | 6 个内联 SVG，均为 `width="20" height="20"`、`stroke="currentColor"` |
| 按钮 | 全部为 `<button type="button">` |
| 数字字体 | `font-variant-numeric: tabular-nums` |

## 3. 交互测试

### 打乱卡片

连续点击 5 次，每次读取 6 个卡片标题：

- 5 次顺序都与上一次不同；
- 每次均为 6 个唯一指标；
- `aria-live` 区域输出：`卡片顺序已更新，第 5 次，共 6 项指标。`

### 主题切换

| 状态 | `<html data-theme>` | `aria-pressed` | 主题按钮标签 | 存储 |
| --- | --- | --- | --- | --- |
| 浅色 | `light` | `false` | 切换到深色模式 | `lumen-theme=light` |
| 深色 | `dark` | `true` | 切换到浅色模式 | `lumen-theme=dark` |

- 切换后卡片 / 页面背景色由 CSS 变量即时更新；
- 刷新后主题从 `localStorage` 恢复；
- 首次访问且无存储时读取 `prefers-color-scheme`。

### 移动端抽屉（390px）

| 状态 | `aria-expanded` | 侧栏可见性 | `workspace inert` | 焦点 |
| --- | --- | --- | --- | --- |
| 关闭 | `false` | `hidden` | 否 | 菜单按钮 |
| 打开 | `true` | `visible` | 是 | 关闭按钮 |
| 按 Esc 关闭 | `false` | `hidden` | 否 | 菜单按钮 |

- 打开时 `body.nav-open` 生效并锁定页面滚动；
- 按 Tab 时焦点在抽屉内部循环；
- 点击遮罩或导航链接也可关闭。

## 4. 控制台

- 运行时异常：0
- 资源加载失败：0
- 页面只引用本地 `assets/styles.css` 与 `assets/app.js`，无外部网络请求。

## 5. 预览截图

- `preview/desktop-1440.png`
- `preview/tablet-768.png`
- `preview/mobile-390.png`
- `preview/mobile-320.png`
- `preview/dark-1440.png`

截图均由最终代码生成，卡片顺序为随机排序结果，与刷新后的实际体验一致。