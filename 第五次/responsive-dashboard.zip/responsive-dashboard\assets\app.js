(function () {
  "use strict";

  var THEME_KEY = "lumen-theme";
  var root = document.documentElement;

  /* ---------------------------------------------------------
     Data
     HTML 中不写任何指标卡片；六张卡片全部由这份数组渲染。
     --------------------------------------------------------- */
  var METRICS = [
    {
      id: "revenue",
      category: "销售表现",
      title: "今日营收",
      prefix: "¥",
      suffix: "",
      value: "128,640",
      delta: "+12.8%",
      direction: "up",
      compare: "较昨日",
      note: "较昨日增加 ¥14,620",
      tone: "violet",
      icon: "revenue",
      series: [36, 42, 39, 48, 45, 58, 53, 66, 62, 74, 70, 83],
      trend: "稳步上行",
      footerLabel: "本月目标完成度",
      footerValue: "86%",
      progress: 86
    },
    {
      id: "orders",
      category: "交易表现",
      title: "订单总量",
      prefix: "",
      suffix: "",
      value: "3,284",
      delta: "+8.2%",
      direction: "up",
      compare: "较昨日",
      note: "新增 248 笔订单",
      tone: "cyan",
      icon: "orders",
      series: [52, 49, 55, 58, 54, 62, 60, 65, 63, 70, 68, 72],
      trend: "持续走高",
      footerLabel: "履约完成率",
      footerValue: "98.6%",
      progress: 98.6
    },
    {
      id: "aov",
      category: "交易表现",
      title: "平均客单价",
      prefix: "¥",
      suffix: "",
      value: "39.17",
      delta: "+2.4%",
      direction: "up",
      compare: "较上周",
      note: "较上周提升 ¥0.92",
      tone: "amber",
      icon: "aov",
      series: [44, 46, 45, 47, 48, 46, 49, 50, 48, 51, 50, 52],
      trend: "小幅上扬",
      footerLabel: "连带购买率",
      footerValue: "42.6%",
      progress: 42.6
    },
    {
      id: "members",
      category: "用户增长",
      title: "新增会员",
      prefix: "",
      suffix: "",
      value: "486",
      delta: "+18.6%",
      direction: "up",
      compare: "较昨日",
      note: "会员注册转化率 6.8%",
      tone: "rose",
      icon: "members",
      series: [22, 28, 26, 35, 31, 41, 39, 48, 45, 56, 52, 61],
      trend: "加速增长",
      footerLabel: "会员复购率",
      footerValue: "57.2%",
      progress: 57.2
    },
    {
      id: "traffic",
      category: "门店表现",
      title: "门店客流",
      prefix: "",
      suffix: "",
      value: "8,912",
      delta: "-3.4%",
      direction: "down",
      compare: "较昨日",
      note: "较昨日减少 314 人次",
      tone: "blue",
      icon: "traffic",
      series: [64, 62, 60, 61, 57, 55, 58, 54, 52, 49, 51, 47],
      trend: "略有回落",
      footerLabel: "高峰时段进店率",
      footerValue: "21.4%",
      progress: 21.4
    },
    {
      id: "satisfaction",
      category: "服务体验",
      title: "顾客满意度",
      prefix: "",
      suffix: "/ 5.0",
      value: "4.86",
      delta: "+0.12",
      direction: "up",
      compare: "较上周",
      note: "基于 2,106 条真实评价",
      tone: "green",
      icon: "satisfaction",
      series: [70, 72, 71, 73, 74, 73, 76, 75, 77, 78, 77, 80],
      trend: "稳中有升",
      footerLabel: "好评率",
      footerValue: "97.2%",
      progress: 97.2
    }
  ];

  var ICONS = {
    revenue:
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<path d="M3.5 8.5A2.5 2.5 0 0 1 6 6h13a1 1 0 0 1 1 1v10.5a2.5 2.5 0 0 1-2.5 2.5H6a2.5 2.5 0 0 1-2.5-2.5v-9z"></path>' +
      '<path d="M3.5 9h14"></path><circle cx="16.5" cy="14" r="1.15"></circle>' +
      "</svg>",
    orders:
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<path d="M6 3h12a1 1 0 0 1 1 1v16l-3-2-2 2-2-2-2 2-3-2V4a1 1 0 0 1 1-1z"></path>' +
      '<path d="M9 8h6M9 12h6M9 16h3"></path>' +
      "</svg>",
    aov:
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<path d="M20.4 13.2l-7.2 7.2a2 2 0 0 1-2.8 0L3.6 13.6a2 2 0 0 1-.6-1.4V5a2 2 0 0 1 2-2h7.2a2 2 0 0 1 1.4.6l6.8 6.8a2 2 0 0 1 0 2.8z"></path>' +
      '<circle cx="8" cy="8" r="1.4"></circle>' +
      "</svg>",
    members:
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<circle cx="9" cy="8" r="3.2"></circle>' +
      '<path d="M3.5 20a5.5 5.5 0 0 1 11 0"></path>' +
      '<path d="M18.5 7v6M15.5 10h6"></path>' +
      "</svg>",
    traffic:
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<path d="M3.5 9.5L5 4h14l1.5 5.5"></path>' +
      '<path d="M4.5 9.5v10h15v-10"></path>' +
      '<path d="M3 9.5h18M8.5 19.5v-5h7v5"></path>' +
      "</svg>",
    satisfaction:
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<circle cx="12" cy="12" r="9"></circle>' +
      '<path d="M8.2 14.2a4.1 4.1 0 0 0 7.6 0"></path>' +
      '<path d="M9 9.5h.01M15 9.5h.01"></path>' +
      "</svg>"
  };

  var cardGrid = document.getElementById("cardGrid");
  var shuffleButton = document.getElementById("shuffleButton");
  var shuffleStatus = document.getElementById("shuffleStatus");
  var themeToggle = document.getElementById("themeToggle");
  var themeColor = document.getElementById("themeColor");

  var menuButton = document.getElementById("menuButton");
  var closeMenuButton = document.getElementById("closeMenu");
  var sidebar = document.getElementById("sidebar");
  var backdrop = document.getElementById("sidebarBackdrop");
  var workspace = document.querySelector(".workspace");
  var desktopQuery = window.matchMedia("(min-width: 1200px)");

  var currentOrder = [];
  var shuffleCount = 0;

  /* ---------------------------------------------------------
     Utilities
     --------------------------------------------------------- */
  function randomInt(max) {
    if (max <= 1) {
      return 0;
    }

    if (window.crypto && typeof window.crypto.getRandomValues === "function") {
      var buffer = new Uint32Array(1);
      var limit = Math.floor(0x100000000 / max) * max;
      var value;

      do {
        window.crypto.getRandomValues(buffer);
        value = buffer[0];
      } while (value >= limit);

      return value % max;
    }

    return Math.floor(Math.random() * max);
  }

  function shuffle(source) {
    var copy = source.slice();

    for (var i = copy.length - 1; i > 0; i -= 1) {
      var j = randomInt(i + 1);
      var temporary = copy[i];
      copy[i] = copy[j];
      copy[j] = temporary;
    }

    return copy;
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(Number(value) || 0, min), max);
  }

  function smoothPath(points) {
    if (!points.length) {
      return "";
    }

    var path = "M " + points[0].x.toFixed(1) + " " + points[0].y.toFixed(1);

    for (var i = 0; i < points.length - 1; i += 1) {
      var p0 = points[i - 1] || points[i];
      var p1 = points[i];
      var p2 = points[i + 1];
      var p3 = points[i + 2] || p2;

      var cp1x = p1.x + (p2.x - p0.x) / 6;
      var cp1y = p1.y + (p2.y - p0.y) / 6;
      var cp2x = p2.x - (p3.x - p1.x) / 6;
      var cp2y = p2.y - (p3.y - p1.y) / 6;

      path +=
        " C " +
        cp1x.toFixed(1) +
        " " +
        cp1y.toFixed(1) +
        ", " +
        cp2x.toFixed(1) +
        " " +
        cp2y.toFixed(1) +
        ", " +
        p2.x.toFixed(1) +
        " " +
        p2.y.toFixed(1);
    }

    return path;
  }

  function sparkline(series, id) {
    var width = 220;
    var height = 56;
    var padX = 3;
    var padY = 7;
    var max = Math.max.apply(null, series);
    var min = Math.min.apply(null, series);
    var range = max - min || 1;
    var step = (width - padX * 2) / Math.max(series.length - 1, 1);

    var points = series.map(function (value, index) {
      return {
        x: padX + step * index,
        y: height - padY - ((value - min) / range) * (height - padY * 2)
      };
    });

    var line = smoothPath(points);
    var first = points[0];
    var last = points[points.length - 1];
    var area =
      line +
      " L " +
      last.x.toFixed(1) +
      " " +
      height +
      " L " +
      first.x.toFixed(1) +
      " " +
      height +
      " Z";
    var gradientId = "spark-gradient-" + id;

    return (
      '<svg class="sparkline" width="' +
      width +
      '" height="' +
      height +
      '" viewBox="0 0 ' +
      width +
      " " +
      height +
      '" preserveAspectRatio="none" aria-hidden="true" focusable="false">' +
      "<defs>" +
      '<linearGradient id="' +
      gradientId +
      '" x1="0" y1="0" x2="0" y2="1">' +
      '<stop class="sparkline__stop-top" offset="0%"></stop>' +
      '<stop class="sparkline__stop-bottom" offset="100%"></stop>' +
      "</linearGradient>" +
      "</defs>" +
      '<path class="sparkline__area" d="' +
      area +
      '" fill="url(#' +
      gradientId +
      ')"></path>' +
      '<path class="sparkline__line" d="' +
      line +
      '"></path>' +
      '<circle class="sparkline__dot" cx="' +
      last.x.toFixed(1) +
      '" cy="' +
      last.y.toFixed(1) +
      '" r="3.2"></circle>' +
      "</svg>"
    );
  }

  function trendArrow(direction) {
    if (direction === "down") {
      return (
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
        '<path d="M12 5v14M6 13l6 6 6-6"></path>' +
        "</svg>"
      );
    }

    return (
      '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<path d="M12 19V5M6 11l6-6 6 6"></path>' +
      "</svg>"
    );
  }

  function cardMarkup(metric, index) {
    var progress = clamp(metric.progress, 0, 100);
    var direction = metric.direction === "down" ? "down" : "up";
    var prefix = metric.prefix
      ? '<span class="stat-card__affix">' + metric.prefix + "</span>"
      : "";
    var suffix = metric.suffix
      ? '<span class="stat-card__suffix">' + metric.suffix + "</span>"
      : "";
    var cardTitleId = "metric-" + metric.id;

    return (
      '<section class="stat-card" data-tone="' +
      metric.tone +
      '" style="--order: ' +
      index +
      '" aria-labelledby="' +
      cardTitleId +
      '">' +
      '<div class="stat-card__head">' +
      '<span class="stat-card__icon" aria-hidden="true">' +
      ICONS[metric.icon] +
      "</span>" +
      '<div class="stat-card__identity">' +
      '<span class="stat-card__category">' +
      metric.category +
      "</span>" +
      '<h3 id="' +
      cardTitleId +
      '">' +
      metric.title +
      "</h3>" +
      "</div>" +
      "</div>" +
      '<div class="stat-card__content">' +
      '<div class="stat-card__primary">' +
      '<p class="stat-card__value">' +
      prefix +
      metric.value +
      suffix +
      "</p>" +
      '<p class="stat-card__trend">' +
      '<span class="delta delta--' +
      direction +
      '">' +
      trendArrow(direction) +
      metric.delta +
      "</span>" +
      '<span class="stat-card__compare">' +
      metric.compare +
      "</span>" +
      "</p>" +
      '<p class="stat-card__note">' +
      metric.note +
      "</p>" +
      "</div>" +
      '<div class="stat-card__chart">' +
      sparkline(metric.series, metric.id) +
      '<div class="stat-card__chart-meta"><span>近 12 日</span><span>' +
      metric.trend +
      "</span></div>" +
      "</div>" +
      "</div>" +
      '<div class="stat-card__footer">' +
      '<div class="stat-card__progress-head"><span>' +
      metric.footerLabel +
      "</span><strong>" +
      metric.footerValue +
      "</strong></div>" +
      '<div class="progress" role="progressbar" aria-label="' +
      metric.title +
      " · " +
      metric.footerLabel +
      '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' +
      progress +
      '" aria-valuetext="' +
      metric.footerValue +
      '"><span style="--value: ' +
      progress +
      '%"></span></div>' +
      "</div>" +
      "</section>"
    );
  }

  function renderCards(items) {
    cardGrid.innerHTML = items.map(cardMarkup).join("");
  }

  function shuffleCards(options) {
    var announce = options && options.announce;
    var next = shuffle(METRICS);
    var sameOrder = next.every(function (metric, index) {
      return currentOrder[index] && currentOrder[index].id === metric.id;
    });

    // 极小概率随机结果与当前顺序相同，主动轮换一位，确保点击“打乱”一定变化。
    if (sameOrder) {
      next = [next[next.length - 1]].concat(next.slice(0, -1));
    }

    currentOrder = next;
    renderCards(next);

    if (announce) {
      shuffleCount += 1;
      shuffleStatus.textContent =
        "卡片顺序已更新，第 " + shuffleCount + " 次，共 " + next.length + " 项指标。";
    }
  }

  /* ---------------------------------------------------------
     Theme
     --------------------------------------------------------- */
  function readStoredTheme() {
    try {
      return window.localStorage.getItem(THEME_KEY);
    } catch (error) {
      return null;
    }
  }

  function storeTheme(theme) {
    try {
      window.localStorage.setItem(THEME_KEY, theme);
    } catch (error) {
      /* localStorage 不可用时仍允许切换当前会话主题 */
    }
  }

  function syncThemeUI() {
    var isDark = root.dataset.theme === "dark";

    if (themeToggle) {
      themeToggle.setAttribute("aria-pressed", isDark ? "true" : "false");
      themeToggle.setAttribute(
        "aria-label",
        isDark ? "切换到浅色模式" : "切换到深色模式"
      );
      themeToggle.setAttribute(
        "title",
        isDark ? "切换到浅色主题" : "切换到深色主题"
      );
    }

    if (themeColor) {
      themeColor.setAttribute("content", isDark ? "#070c17" : "#f4f6fb");
    }
  }

  function applyTheme(theme, persist) {
    if (theme !== "light" && theme !== "dark") {
      return;
    }

    root.dataset.theme = theme;
    if (persist) {
      storeTheme(theme);
    }
    syncThemeUI();
  }

  if (themeToggle) {
    syncThemeUI();

    themeToggle.addEventListener("click", function () {
      applyTheme(root.dataset.theme === "dark" ? "light" : "dark", true);
    });
  }

  if (window.matchMedia) {
    var systemTheme = window.matchMedia("(prefers-color-scheme: dark)");
    var onSystemThemeChange = function (event) {
      if (!readStoredTheme()) {
        applyTheme(event.matches ? "dark" : "light", false);
      }
    };

    if (typeof systemTheme.addEventListener === "function") {
      systemTheme.addEventListener("change", onSystemThemeChange);
    } else if (typeof systemTheme.addListener === "function") {
      systemTheme.addListener(onSystemThemeChange);
    }
  }

  /* ---------------------------------------------------------
     Mobile drawer
     --------------------------------------------------------- */
  function isDrawerOpen() {
    return document.body.classList.contains("nav-open");
  }

  function openMenu() {
    if (desktopQuery.matches || isDrawerOpen()) {
      return;
    }

    sidebar.removeAttribute("inert");
    sidebar.classList.add("is-open");
    document.body.classList.add("nav-open");
    menuButton.setAttribute("aria-expanded", "true");
    if (workspace) {
      workspace.setAttribute("inert", "");
    }

    window.requestAnimationFrame(function () {
      closeMenuButton.focus();
    });
  }

  function closeMenu(options) {
    var restoreFocus = !options || options.restoreFocus !== false;
    var wasOpen = isDrawerOpen();

    sidebar.classList.remove("is-open");
    document.body.classList.remove("nav-open");
    menuButton.setAttribute("aria-expanded", "false");

    if (workspace) {
      workspace.removeAttribute("inert");
    }

    if (wasOpen && restoreFocus) {
      menuButton.focus({ preventScroll: true });
    }

    if (!desktopQuery.matches) {
      sidebar.setAttribute("inert", "");
    }
  }

  function syncDrawerMode() {
    if (desktopQuery.matches) {
      if (isDrawerOpen()) {
        closeMenu({ restoreFocus: false });
      }
      sidebar.removeAttribute("inert");
      if (workspace) {
        workspace.removeAttribute("inert");
      }
      menuButton.setAttribute("aria-expanded", "false");
    } else if (!isDrawerOpen()) {
      sidebar.setAttribute("inert", "");
    }
  }

  if (menuButton && sidebar && closeMenuButton && backdrop) {
    menuButton.addEventListener("click", openMenu);
    closeMenuButton.addEventListener("click", function () {
      closeMenu();
    });
    backdrop.addEventListener("click", function () {
      closeMenu();
    });

    document.addEventListener("keydown", function (event) {
      if (!isDrawerOpen()) {
        return;
      }

      if (event.key === "Escape") {
        event.preventDefault();
        closeMenu();
        return;
      }

      if (event.key !== "Tab") {
        return;
      }

      var focusable = Array.prototype.slice
        .call(
          sidebar.querySelectorAll(
            'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
          )
        )
        .filter(function (element) {
          return element.getClientRects().length > 0;
        });

      if (!focusable.length) {
        return;
      }

      var first = focusable[0];
      var last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });

    Array.prototype.forEach.call(
      sidebar.querySelectorAll('a[href^="#"]'),
      function (link) {
        link.addEventListener("click", function () {
          if (!desktopQuery.matches && isDrawerOpen()) {
            closeMenu();
          }
        });
      }
    );

    if (typeof desktopQuery.addEventListener === "function") {
      desktopQuery.addEventListener("change", syncDrawerMode);
    } else if (typeof desktopQuery.addListener === "function") {
      desktopQuery.addListener(syncDrawerMode);
    }

    syncDrawerMode();
  }

  /* ---------------------------------------------------------
     Navigation highlight
     --------------------------------------------------------- */
  var navLinks = Array.prototype.slice.call(
    document.querySelectorAll(".nav__link")
  );
  var navSections = navLinks
    .map(function (link) {
      return document.getElementById(link.getAttribute("data-section"));
    })
    .filter(Boolean);
  var activeSectionId = "";

  function setActiveSection(id) {
    if (!id || id === activeSectionId) {
      return;
    }

    activeSectionId = id;
    navLinks.forEach(function (link) {
      var isActive = link.getAttribute("data-section") === id;
      link.classList.toggle("is-active", isActive);

      if (isActive) {
        link.setAttribute("aria-current", "location");
      } else {
        link.removeAttribute("aria-current");
      }
    });
  }

  function updateActiveSection() {
    if (!navSections.length) {
      return;
    }

    var marker = window.scrollY + Math.min(window.innerHeight * 0.32, 260);
    var current = navSections[0];

    for (var i = 0; i < navSections.length; i += 1) {
      if (navSections[i].getBoundingClientRect().top <= marker) {
        current = navSections[i];
      } else {
        break;
      }
    }

    setActiveSection(current.id);
  }

  var sectionTicking = false;

  window.addEventListener(
    "scroll",
    function () {
      if (sectionTicking) {
        return;
      }

      sectionTicking = true;
      window.requestAnimationFrame(function () {
        updateActiveSection();
        sectionTicking = false;
      });
    },
    { passive: true }
  );

  window.addEventListener("resize", updateActiveSection, { passive: true });

  /* ---------------------------------------------------------
     Boot
     --------------------------------------------------------- */
  shuffleCards();
  updateActiveSection();

  if (shuffleButton) {
    shuffleButton.addEventListener("click", function () {
      shuffleCards({ announce: true });
    });
  }
})();