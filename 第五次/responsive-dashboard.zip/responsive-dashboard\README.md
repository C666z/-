# 澄光数据 · 响应式经营看板

一个使用 **HTML + CSS + 原生 JavaScript** 构建的经营数据看板。页面在手机、平板、桌面三档宽度下使用不同布局，包含 6 个由 JavaScript 随机排序的数据卡片、浅色 / 深色主题切换、移动端抽屉导航，以及完整的键盘和读屏支持。

- 无框架、无构建工具、无第三方依赖
- 双击 `index.html` 即可运行（`file://` 协议）
- 已实测 320px–1920px 无横向滚动

![桌面端 1440px 浅色主题](preview/desktop-1440.png)

## 快速运行

直接双击 `index.html` 即可。

也可以在当前目录启动一个本地静态服务器：

```powershell
python -m http.server 8080
```

然后访问 `http://localhost:8080/`。

## 三档响应式布局

| 视口宽度 | 卡片布局 | 导航形态 | 页面行为 |
| --- | --- | --- | --- |
| `< 768px` | 单列 | 抽屉导航 + 顶部菜单按钮 | 卡片、图表、页头全部纵向排列 |
| `768px – 1199px` | 两列 | 抽屉导航 + 顶部菜单按钮 | 桌面侧栏收起，内容区占满宽度 |
| `≥ 1200px` | 四列 + 固定侧栏 | 常驻侧栏 | 第 5、6 张卡片各跨两列，第二行铺满 |

断点为纯 CSS 媒体查询，卡片网格使用 `minmax(0, 1fr)`，没有写死 `1200px` 内容宽度。

## 功能清单

- **6 张数据卡片**：营收、订单、客单价、新增会员、门店客流、满意度。全部由 `assets/app.js` 中的 `METRICS` 数组渲染，HTML 中没有任何一张卡片模板。
- **随机排序**：页面加载时使用 Fisher–Yates 洗牌 + `crypto.getRandomValues`；点击「打乱卡片」可再次排序，连续点击时保证顺序一定发生变化。
- **主题切换**：浅色 / 深色两套 CSS 变量，支持 `localStorage` 记忆和系统主题偏好，首屏绘制前恢复主题避免闪屏。
- **移动端抽屉**：打开后锁定页面滚动、`workspace` 设为 `inert`、焦点移动到关闭按钮；支持 Esc、遮罩关闭和焦点归还。
- **导航联动**：滚动时自动高亮当前区块，导航使用 `aria-current="location"`。
- **数字稳定**：所有数字继承 `font-variant-numeric: tabular-nums`，切换主题、更新数据时不会因字宽抖动。
- **无障碍**：跳转链接、语义化标题层级、卡片 `section`、按钮 `type="button"`、进度条 `role="progressbar"`、可见焦点环、`prefers-reduced-motion` 支持。

## 课程要求对照

| # | 要求 | 实现位置 |
| --- | --- | --- |
| 1 | `< 768` 单列、`768–1199` 两列、`≥1200` 四列 + 侧栏 | `assets/styles.css` 的 `768px` / `1200px` 媒体查询 |
| 2 | 卡片使用 grid 的 `auto-fit` / `minmax()` 或 flex-wrap，不写死 1200px | `.dashboard-grid` 使用 `repeat(n, minmax(0, 1fr))`，内容宽度自适应 |
| 3 | 320px–1920px 不出现横向滚动条 | 使用 `minmax(0, 1fr)`、`min-width: 0`、`clamp()`、弹性换行；15 个宽度实测通过 |
| 4 | 6 条数据由 JS 渲染，不写 6 段重复 HTML | `index.html` 中只有空的 `#cardGrid`，`app.js` 中由 `METRICS.map(cardMarkup)` 生成 |
| 5 | 数字使用 `font-variant-numeric: tabular-nums` | `body` 统一声明，数字元素继承 |
| 6 | CSS 变量管理颜色，至少一组深 / 浅色可切换（加分） | `:root` 与 `[data-theme="dark"]` 两套 token，右上角按钮切换 |
| 7 | 图片 / 图标有明确尺寸，图标内联 SVG + `currentColor` | 所有图标为内联 SVG，显式 `width` / `height`，`stroke="currentColor"` |
| 8 | 语义化：`h1` / `h2`、卡片 `section`、切换按钮 `button` | 页面 1 个 `h1`、3 个 `h2`；6 张卡片均为 `section`；交互均为 `button` |

## 目录结构

```text
responsive-dashboard/
├── index.html                  # 页面结构、侧栏、图表、无障碍标记
├── assets/
│   ├── styles.css              # 设计变量、布局、三档断点、深色主题
│   └── app.js                  # 6 项指标数据、洗牌、主题、抽屉、滚动高亮
├── preview/                    # 验收截图
│   ├── desktop-1440.png
│   ├── tablet-768.png
│   ├── mobile-390.png
│   ├── mobile-320.png
│   └── dark-1440.png
├── README.md
├── PROMPT.md                   # 本次实现的完整 Prompt
├── VERIFICATION.md             # 自动化验收记录
├── push-to-gitee.ps1           # 一键推送脚本
└── .gitignore
```

## 实现要点

1. **数据与视图分离**：`METRICS` 只包含数据、配色、图标名和折线序列；`cardMarkup()` 负责生成唯一 DOM；折线路径由 `smoothPath()` 根据数据实时计算。
2. **断点稳定**：桌面端内容宽度 = 视口 − 侧栏 − 页边距；四列卡片用 `minmax(0, 1fr)` 分配，数值用 `clamp()` 缩放，因此 1200px 下也不会撑破容器。
3. **桌面端第二行**：`nth-last-child(-n + 2)` 让最后两张卡片各跨两列，避免 4 + 2 留下的空洞，同时不改变数据条数。
4. **移动端可关闭**：抽屉关闭时设置 `inert`，避免键盘 Tab 进入屏幕外的链接；打开时把背景工作区设为 `inert`，实现焦点隔离。
5. **不依赖外部资源**：字体使用系统字体栈，图标全部内联，离线双击也能完整显示。

## 验证结果

自动化脚本在 Microsoft Edge 156 中测试了 15 个视口宽度，全部无横向滚动：

```text
320 / 360 / 375 / 390 / 480 / 767 / 768 / 900 / 1024 / 1199 /
1200 / 1366 / 1440 / 1600 / 1920
```

- 320px 单列，768px 两列，1200px 四列 + 侧栏
- 6 张卡片、每张均为 `section`
- 5 次「打乱卡片」均得到不同顺序，且始终包含 6 个唯一指标
- 深 / 浅主题切换正常写入 `localStorage`，按钮 `aria-pressed` 同步
- 移动端抽屉打开后焦点落到关闭按钮，Esc 关闭后焦点回到菜单按钮
- 控制台无运行时错误

详细记录见 [VERIFICATION.md](VERIFICATION.md)。

## 推送到 Gitee

先在 Gitee 创建一个 **空的公开仓库**，然后在本目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\push-to-gitee.ps1 -RepoUrl "https://gitee.com/你的用户名/仓库名.git"
```

脚本会自动初始化 Git（如果还没有）、提交源码并推送 `main` 分支。推送完成后，Gitee 仓库地址就是可公开访问的项目链接。

> 说明：创建 Gitee 仓库和首次推送需要你的 Gitee 账号授权，脚本不会包含或上传任何账号凭据。

## 数据说明

页面中的门店、金额、订单与趋势均为课程演示数据，不代表真实经营数据。