﻿param(
  [Parameter(Mandatory = $true, HelpMessage = "例如 https://gitee.com/your-name/lumen-dashboard.git")]
  [ValidatePattern('^(https://gitee\.com/|git@gitee\.com:)')]
  [string]$RepoUrl,

  [string]$Branch = "main"
)

$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "未找到 git，请先安装 Git 并加入 PATH。"
}

if (-not (Test-Path -LiteralPath ".git")) {
  git init -b $Branch
  if ($LASTEXITCODE -ne 0) {
    throw "git init 失败。"
  }
}

# 只写入当前仓库的本地身份，不修改全局 Git 配置。
$name = git config --local user.name
if ([string]::IsNullOrWhiteSpace($name)) {
  git config --local user.name "Lumen Dashboard"
}
$email = git config --local user.email
if ([string]::IsNullOrWhiteSpace($email)) {
  git config --local user.email "lumen-dashboard@local"
}

git add --all
if ($LASTEXITCODE -ne 0) {
  throw "git add 失败。"
}

$hasHead = $false
git rev-parse --verify HEAD *> $null
if ($LASTEXITCODE -eq 0) {
  $hasHead = $true
}

git diff --cached --quiet
$hasStagedChanges = $LASTEXITCODE -ne 0

if (-not $hasHead) {
  git commit -m "feat: responsive data dashboard"
  if ($LASTEXITCODE -ne 0) {
    throw "git commit 失败，请检查 Git 配置。"
  }
} elseif ($hasStagedChanges) {
  git commit -m "chore: update dashboard"
  if ($LASTEXITCODE -ne 0) {
    throw "git commit 失败，请检查 Git 配置。"
  }
}

$existingRemote = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($existingRemote)) {
  git remote set-url origin $RepoUrl
} else {
  git remote add origin $RepoUrl
}

git push -u origin $Branch
if ($LASTEXITCODE -ne 0) {
  throw "推送失败。请确认 Gitee 仓库已创建为空的公开仓库，且本机已登录 Gitee。"
}

Write-Host ""
Write-Host "推送完成。公开仓库地址：" -ForegroundColor Green
Write-Host ($RepoUrl -replace '\.git$', '')